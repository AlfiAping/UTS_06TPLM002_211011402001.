package com.example.uts_pirmansyah_21011400604

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
